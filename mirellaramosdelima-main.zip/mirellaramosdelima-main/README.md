# bem vindos a aula de Progrmação front-end 👩‍💻
👋olá,meu nome é Mirella ramos de lima 
- :+1:Meu email de contato Lima.mirella@escola.pr.gov.br
- :+1:Meu email de contato especial é lmirella623@gmail.com

**Eu estou interessado em aprender a programar novas linguagens**

**Eu estudo desenvolvimento de sistemas**
